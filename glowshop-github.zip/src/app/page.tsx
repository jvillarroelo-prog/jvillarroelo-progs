'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Sparkles, Heart, Dumbbell, Droplets, Flower2,
  Star, ArrowRight, CheckCircle, Mail, TrendingUp,
  ChevronRight, Menu, X, ExternalLink, ShoppingCart,
  Percent, BadgePercent, Clock, Gift, Zap, Crown,
  ShieldCheck, Truck, RefreshCw
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'

// Category icons mapping
const categoryIcons: Record<string, typeof Sparkles> = {
  'Sparkles': Sparkles,
  'Heart': Heart,
  'Dumbbell': Dumbbell,
  'Droplets': Droplets,
  'Flower2': Flower2
}

interface Product {
  id: string
  name: string
  slug: string
  description: string
  shortDesc: string | null
  features: string
  benefits: string | null
  price: number
  originalPrice: number | null
  commission: number
  rating: number
  reviewCount: number
  affiliateUrl: string
  imageUrl: string | null
  brand: string | null
  featured: boolean
  bestSeller: boolean
  category: {
    name: string
    slug: string
    color?: string
  }
}

interface Category {
  id: string
  name: string
  slug: string
  description: string | null
  icon: string | null
  color: string | null
  _count?: { products: number }
}

export default function Home() {
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [email, setEmail] = useState('')
  const [subscribing, setSubscribing] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [productsRes, categoriesRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/categories')
      ])
      const productsData = await productsRes.json()
      const categoriesData = await categoriesRes.json()
      setProducts(productsData)
      setCategories(categoriesData)
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email) return

    setSubscribing(true)
    try {
      const res = await fetch('/api/subscribers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, source: 'homepage' })
      })
      const data = await res.json()
      toast.success(data.message || '¡Gracias por suscribirte!')
      setEmail('')
    } catch {
      toast.error('Error al suscribir. Intenta de nuevo.')
    } finally {
      setSubscribing(false)
    }
  }

  const featuredProducts = products.filter(p => p.featured)
  const bestSellers = products.filter(p => p.bestSeller)
  const filteredProducts = selectedCategory 
    ? products.filter(p => p.category.slug === selectedCategory)
    : products

  const calculateDiscount = (price: number, original?: number | null) => {
    if (!original) return 0
    return Math.round(((original - price) / original) * 100)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-white to-purple-50">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-pink-600 via-purple-600 to-pink-600 text-white py-2.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 text-sm">
          <Percent className="w-4 h-4" />
          <span className="font-medium">OFERTAS EXCLUSIVAS: Hasta 50% OFF + Envío Gratis en pedidos +$50</span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </div>

      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-lg border-b border-pink-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-pink-500/25">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                  GlowShop
                </span>
                <span className="hidden sm:inline text-xs text-gray-400 ml-1">by Afiliados</span>
              </div>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-6">
              <a href="#categorias" className="text-gray-600 hover:text-pink-600 transition-colors text-sm font-medium">Categorías</a>
              <a href="#ofertas" className="text-gray-600 hover:text-pink-600 transition-colors text-sm font-medium">Ofertas</a>
              <a href="#bestsellers" className="text-gray-600 hover:text-pink-600 transition-colors text-sm font-medium">Best Sellers</a>
              <Button className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 shadow-lg shadow-pink-500/25">
                <Mail className="w-4 h-4 mr-2" />
                Newsletter
              </Button>
            </div>

            {/* Mobile menu button */}
            <button 
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-b border-pink-100 px-4 py-4 space-y-3"
            >
              <a href="#categorias" className="block text-gray-600 hover:text-pink-600 py-2">Categorías</a>
              <a href="#ofertas" className="block text-gray-600 hover:text-pink-600 py-2">Ofertas</a>
              <a href="#bestsellers" className="block text-gray-600 hover:text-pink-600 py-2">Best Sellers</a>
              <Button className="w-full bg-gradient-to-r from-pink-500 to-purple-600">Newsletter</Button>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-12 md:py-20">
        <div className="absolute inset-0 bg-gradient-to-br from-pink-100/50 via-purple-50 to-pink-100/30"></div>
        <div className="absolute top-10 right-10 w-64 h-64 bg-pink-300/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 left-10 w-64 h-64 bg-purple-300/30 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Badge className="mb-4 bg-pink-100 text-pink-700 hover:bg-pink-100 px-3 py-1.5">
                <Crown className="w-3 h-3 mr-1" />
                Productos Premium Seleccionados
              </Badge>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Belleza, Salud &
                <span className="block bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                  Bienestar Premium
                </span>
              </h1>
              
              <p className="mt-6 text-lg text-gray-600 max-w-xl">
                Descubre productos cuidadosamente seleccionados con <strong>ofertas exclusivas</strong> y 
                <strong> descuentos de hasta 50%</strong>. Tu bienestar al mejor precio.
              </p>

              {/* Trust badges */}
              <div className="mt-8 flex flex-wrap gap-4">
                <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm">
                  <Truck className="w-5 h-5 text-pink-600" />
                  <span className="text-sm font-medium text-gray-700">Envío Gratis +$50</span>
                </div>
                <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm">
                  <ShieldCheck className="w-5 h-5 text-green-600" />
                  <span className="text-sm font-medium text-gray-700">Garantía 30 días</span>
                </div>
                <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm">
                  <RefreshCw className="w-5 h-5 text-blue-600" />
                  <span className="text-sm font-medium text-gray-700">Devolución Fácil</span>
                </div>
              </div>
              
              <div className="mt-8 flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-lg px-8 py-6 rounded-xl shadow-xl shadow-pink-500/25">
                  Ver Ofertas del Día
                  <BadgePercent className="ml-2 w-5 h-5" />
                </Button>
                <Button size="lg" variant="outline" className="text-lg px-8 py-6 rounded-xl border-2 border-pink-200 hover:border-pink-400 hover:bg-pink-50">
                  <ShoppingCart className="mr-2 w-5 h-5" />
                  Best Sellers
                </Button>
              </div>
            </motion.div>

            {/* Hero Stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-4">
                <Card className="bg-gradient-to-br from-pink-500 to-rose-600 text-white border-0">
                  <CardContent className="p-6">
                    <div className="text-4xl font-bold">50%+</div>
                    <div className="text-pink-100 mt-1">Descuentos</div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white border-0">
                  <CardContent className="p-6">
                    <div className="text-4xl font-bold">18+</div>
                    <div className="text-purple-100 mt-1">Productos Top</div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-amber-500 to-orange-600 text-white border-0">
                  <CardContent className="p-6">
                    <div className="text-4xl font-bold">4.8★</div>
                    <div className="text-amber-100 mt-1">Rating Promedio</div>
                  </CardContent>
                </Card>
                <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white border-0">
                  <CardContent className="p-6">
                    <div className="text-4xl font-bold">100K+</div>
                    <div className="text-emerald-100 mt-1">Clientes Felices</div>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section id="categorias" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Explora por Categoría
            </h2>
            <p className="mt-3 text-gray-600">
              Encuentra exactamente lo que necesitas
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories.map((category, index) => {
              const IconComponent = category.icon ? categoryIcons[category.icon] || Sparkles : Sparkles
              const isSelected = selectedCategory === category.slug
              return (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card 
                    className={`cursor-pointer transition-all hover:shadow-lg hover:-translate-y-1 ${
                      isSelected 
                        ? 'ring-2 ring-pink-500 bg-pink-50 shadow-lg' 
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedCategory(isSelected ? null : category.slug)}
                  >
                    <CardContent className="p-5 text-center">
                      <div 
                        className={`w-14 h-14 mx-auto rounded-2xl flex items-center justify-center mb-3 transition-all ${
                          isSelected
                            ? 'bg-gradient-to-br from-pink-500 to-purple-600 text-white shadow-lg'
                            : 'bg-gray-100 text-gray-600'
                        }`}
                        style={!isSelected ? { backgroundColor: `${category.color}15`, color: category.color || undefined } : undefined}
                      >
                        <IconComponent className="w-7 h-7" />
                      </div>
                      <h3 className="font-semibold text-gray-900 text-sm">{category.name}</h3>
                      <p className="text-xs text-gray-500 mt-1">
                        {category._count?.products || 0} productos
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>

          {selectedCategory && (
            <div className="mt-6 text-center">
              <Button 
                variant="ghost" 
                onClick={() => setSelectedCategory(null)}
                className="text-gray-500"
              >
                <X className="w-4 h-4 mr-2" />
                Ver todos los productos
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Featured Products - OFERTAS */}
      <section id="ofertas" className="py-16 bg-gradient-to-b from-pink-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <BadgePercent className="w-6 h-6 text-pink-600" />
                <Badge className="bg-pink-100 text-pink-700 hover:bg-pink-100">OFERTAS ESPECIALES</Badge>
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
                Ofertas del Día
              </h2>
              <p className="mt-2 text-gray-600">Ahorra hasta 50% en productos premium</p>
            </div>
            <div className="hidden md:flex items-center gap-2 text-pink-600">
              <Clock className="w-5 h-5" />
              <span className="font-medium">Terminan en 24h</span>
            </div>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="h-40 bg-gray-200 rounded-lg mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {(selectedCategory ? filteredProducts : featuredProducts).slice(0, 8).map((product, index) => {
                const discount = calculateDiscount(product.price, product.originalPrice)
                return (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Card className="group h-full hover:shadow-xl transition-all duration-300 overflow-hidden border-pink-100 hover:border-pink-300 bg-white">
                      {/* Product Image */}
                      <div className="relative h-48 bg-gradient-to-br from-pink-50 to-purple-50 overflow-hidden">
                        {product.imageUrl && (
                          <img 
                            src={product.imageUrl} 
                            alt={product.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        )}
                        
                        {/* Discount Badge */}
                        {discount > 0 && (
                          <div className="absolute top-3 left-3 bg-gradient-to-r from-pink-500 to-rose-600 text-white px-2 py-1 rounded-lg text-xs font-bold shadow-lg">
                            -{discount}%
                          </div>
                        )}
                        
                        {/* Best Seller Badge */}
                        {product.bestSeller && (
                          <div className="absolute top-3 right-3 bg-gradient-to-r from-amber-400 to-orange-500 text-white px-2 py-1 rounded-lg text-xs font-bold shadow-lg flex items-center gap-1">
                            <Zap className="w-3 h-3" />
                            TOP
                          </div>
                        )}
                      </div>
                      
                      <CardContent className="p-4">
                        {/* Brand */}
                        {product.brand && (
                          <p className="text-xs text-pink-600 font-medium mb-1">{product.brand}</p>
                        )}
                        
                        {/* Name */}
                        <h3 className="font-semibold text-gray-900 line-clamp-2 group-hover:text-pink-600 transition-colors">
                          {product.name}
                        </h3>
                        
                        {/* Rating */}
                        <div className="flex items-center gap-1 mt-2">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star 
                                key={star} 
                                className={`w-3.5 h-3.5 ${star <= Math.round(product.rating) ? 'fill-amber-400 text-amber-400' : 'fill-gray-200 text-gray-200'}`} 
                              />
                            ))}
                          </div>
                          <span className="text-xs text-gray-500">({product.reviewCount.toLocaleString()})</span>
                        </div>
                        
                        {/* Price */}
                        <div className="mt-3 flex items-baseline gap-2">
                          <span className="text-2xl font-bold text-gray-900">${product.price}</span>
                          {product.originalPrice && (
                            <span className="text-sm text-gray-400 line-through">${product.originalPrice}</span>
                          )}
                        </div>
                        
                        {/* Commission Badge - Internal use indicator */}
                        <div className="mt-2 text-xs text-gray-500">
                          Comisión: <span className="text-green-600 font-semibold">{product.commission}%</span>
                        </div>
                      </CardContent>
                      
                      <CardFooter className="p-4 pt-0">
                        <Button 
                          className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 group/btn"
                          onClick={() => window.open(product.affiliateUrl, '_blank')}
                        >
                          Ver Oferta
                          <ExternalLink className="ml-2 w-4 h-4 group-hover/btn:translate-x-0.5 transition-transform" />
                        </Button>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </div>
      </section>

      {/* Best Sellers */}
      <section id="bestsellers" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Zap className="w-6 h-6 text-amber-500" />
              <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">MÁS VENDIDOS</Badge>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Los Favoritos de Nuestros Clientes
            </h2>
            <p className="mt-2 text-gray-600">Productos con miles de reseñas positivas</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bestSellers.slice(0, 6).map((product, index) => {
              const discount = calculateDiscount(product.price, product.originalPrice)
              return (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card className="group flex flex-col md:flex-row overflow-hidden hover:shadow-xl transition-all border-amber-200 hover:border-amber-400">
                    {/* Image */}
                    <div className="relative w-full md:w-40 h-40 md:h-auto bg-gradient-to-br from-amber-50 to-orange-50 flex-shrink-0">
                      {product.imageUrl && (
                        <img 
                          src={product.imageUrl} 
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      )}
                      {discount > 0 && (
                        <Badge className="absolute top-2 left-2 bg-gradient-to-r from-amber-500 to-orange-600 text-white text-xs">
                          -{discount}%
                        </Badge>
                      )}
                      <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm rounded-full p-1.5">
                        <span className="text-xs font-bold text-amber-600">#{index + 1}</span>
                      </div>
                    </div>
                    
                    {/* Content */}
                    <div className="flex-1 p-4 flex flex-col">
                      {product.brand && (
                        <p className="text-xs text-amber-600 font-medium">{product.brand}</p>
                      )}
                      <h3 className="font-semibold text-gray-900 group-hover:text-amber-600 transition-colors">
                        {product.name}
                      </h3>
                      <p className="text-sm text-gray-500 mt-1 line-clamp-2">{product.shortDesc}</p>
                      
                      <div className="flex items-center gap-1 mt-2">
                        <div className="flex">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star 
                              key={star} 
                              className={`w-3 h-3 ${star <= Math.round(product.rating) ? 'fill-amber-400 text-amber-400' : 'fill-gray-200 text-gray-200'}`} 
                            />
                          ))}
                        </div>
                        <span className="text-xs text-gray-500">{product.reviewCount.toLocaleString()} reseñas</span>
                      </div>
                      
                      <div className="mt-auto pt-3 flex items-center justify-between">
                        <div className="flex items-baseline gap-2">
                          <span className="text-xl font-bold text-gray-900">${product.price}</span>
                          {product.originalPrice && (
                            <span className="text-sm text-gray-400 line-through">${product.originalPrice}</span>
                          )}
                        </div>
                        <Button 
                          size="sm"
                          className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700"
                          onClick={() => window.open(product.affiliateUrl, '_blank')}
                        >
                          Ver
                          <ExternalLink className="ml-1 w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Benefits Banner */}
      <section className="py-12 bg-gradient-to-r from-pink-600 via-purple-600 to-pink-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-6 text-white text-center">
            {[
              { icon: Truck, title: 'Envío Gratis', desc: 'En pedidos +$50' },
              { icon: ShieldCheck, title: 'Compra Segura', desc: 'Pago 100% protegido' },
              { icon: RefreshCw, title: 'Devolución Fácil', desc: '30 días para devolver' },
              { icon: Gift, title: 'Ofertas Exclusivas', desc: 'Solo para suscriptores' },
            ].map((item, index) => (
              <div key={index} className="flex flex-col items-center gap-2">
                <item.icon className="w-8 h-8" />
                <div className="font-semibold">{item.title}</div>
                <div className="text-sm text-pink-200">{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-gradient-to-br from-pink-50 via-purple-50 to-pink-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-pink-500/25">
              <Mail className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Recibe Ofertas Exclusivas
            </h2>
            <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
              Únete a nuestra comunidad y recibe ofertas especiales, lanzamientos de productos 
              y descuentos exclusivos directamente en tu correo.
            </p>

            <form onSubmit={handleSubscribe} className="mt-8 flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
              <Input
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 h-14 px-6 text-lg bg-white border-pink-200 focus:border-pink-500 focus:ring-pink-500"
                required
              />
              <Button 
                type="submit" 
                size="lg"
                disabled={subscribing}
                className="h-14 px-8 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-lg font-semibold shadow-xl shadow-pink-500/25"
              >
                {subscribing ? 'Enviando...' : 'Suscribirme'}
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </form>

            <p className="mt-4 text-sm text-gray-500">
              🔒 Sin spam. Cancela cuando quieras. +50,000 suscriptores felices.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-bold">GlowShop</span>
              </div>
              <p className="text-gray-400 max-w-md">
                Tu destino para productos de belleza, salud y bienestar premium. 
                Ofertas exclusivas y descuentos de hasta 50%.
              </p>
              <p className="mt-6 text-sm text-gray-500">
                © 2024 GlowShop. Todos los derechos reservados.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Categorías</h3>
              <ul className="space-y-2 text-gray-400">
                {categories.map(cat => (
                  <li key={cat.id}>
                    <a href="#" className="hover:text-white transition-colors">{cat.name}</a>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Política de Privacidad</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Términos de Uso</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Divulgación de Afiliados</a></li>
              </ul>
            </div>
          </div>
          
          <div className="mt-10 pt-8 border-t border-gray-800 text-center text-sm text-gray-500">
            <p>Este sitio contiene enlaces de afiliados. Ganamos una comisión por las compras realizadas a través de nuestros enlaces, sin costo adicional para ti.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
