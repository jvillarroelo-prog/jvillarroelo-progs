# GlowShop - Tienda de E-Commerce Afiliado

Tienda de productos de belleza, salud y bienestar con marketing de afiliados.

## Cómo usar

1. Sube este proyecto a GitHub
2. Conecta con Vercel
3. ¡Tu tienda online!

## Configurar enlaces de afiliado

Edita el archivo `AFFILIATE_PRODUCTS.json` y reemplaza `"TU_ENLACE_AQUI"` con tus enlaces reales de afiliado.

## Comisiones

- ShareASale: 20-50%
- Amazon Associates: 1-10%
- Impact: 30-50%

---
Creado con Next.js 16 + Tailwind CSS
