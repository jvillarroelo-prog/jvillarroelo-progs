import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const categories = [
  {
    name: 'Belleza y Cuidado de la Piel',
    slug: 'belleza-cuidado-piel',
    description: 'Productos premium para realzar tu belleza natural',
    icon: 'Sparkles',
    color: '#EC4899' // Pink
  },
  {
    name: 'Salud y Bienestar',
    slug: 'salud-bienestar',
    description: 'Suplementos y productos para una vida más saludable',
    icon: 'Heart',
    color: '#10B981' // Green
  },
  {
    name: 'Fitness y Deportes',
    slug: 'fitness-deportes',
    description: 'Todo lo que necesitas para tu rutina de ejercicios',
    icon: 'Dumbbell',
    color: '#F59E0B' // Amber
  },
  {
    name: 'Cuidado Personal',
    slug: 'cuidado-personal',
    description: 'Productos esenciales para el cuidado diario',
    icon: 'Droplets',
    color: '#8B5CF6' // Purple
  },
  {
    name: 'Aromaterapia y Spa',
    slug: 'aromaterapia-spa',
    description: 'Aceites esenciales y productos de relajación',
    icon: 'Flower2',
    color: '#06B6D4' // Cyan
  }
]

const products = [
  // ===== BELLEZA Y CUIDADO DE LA PIEL =====
  {
    name: 'Sérum Vitamina C Premium',
    slug: 'serum-vitamina-c-premium',
    description: 'Sérum concentrado con vitamina C 20%, ácido hialurónico y vitamina E. Ilumina la piel, reduce manchas y líneas de expresión en solo 4 semanas de uso continuo.',
    shortDesc: 'Antioxidante poderoso para piel radiante',
    features: JSON.stringify(['Vitamina C 20% estabilizada', 'Ácido hialurónico puro', 'Frasco oscuro protector UV', 'Textura ligera no grasa', 'Apto para todo tipo de piel']),
    benefits: JSON.stringify(['Reduce manchas y cicatrices', 'Piel más luminosa en 2 semanas', 'Disminuye líneas finas', 'Protección antioxidante', 'Hidratación profunda']),
    price: 34.99,
    originalPrice: 59.99,
    commission: 45,
    rating: 4.8,
    reviewCount: 4520,
    affiliateUrl: 'https://shareasale.com/m-12345',
    imageUrl: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400',
    brand: 'GlowSkin',
    categorySlug: 'belleza-cuidado-piel',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Kit Completo Skincare 7 Pasos',
    slug: 'kit-skincare-7-pasos',
    description: 'Rutina coreana completa con 7 productos premium: limpiador, tónico, sérum, contorno de ojos, crema hidratante, mascarilla nocturna y protector solar SPF 50.',
    shortDesc: 'Todo lo que necesitas para una piel perfecta',
    features: JSON.stringify(['7 productos full size', 'Ingredientes naturales coreanos', 'Apto para pieles sensibles', 'Bolsa de viaje incluida', 'Guía de uso detallada']),
    benefits: JSON.stringify(['Rutina completa en un kit', 'Ahorra vs comprar individual', 'Resultados visibles en 30 días', 'Ingredientes premium', 'Ideal para regalar']),
    price: 89.99,
    originalPrice: 149.99,
    commission: 40,
    rating: 4.9,
    reviewCount: 2340,
    affiliateUrl: 'https://shareasale.com/m-12346',
    imageUrl: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400',
    brand: 'K-Beauty Pro',
    categorySlug: 'belleza-cuidado-piel',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Crema Anti-Edad Retinol 1%',
    slug: 'crema-anti-edad-retinol',
    description: 'Tratamiento nocturno con retinol encapsulado de liberación gradual. Reduce arrugas, poros visibles y mejora la textura de la piel mientras duermes.',
    shortDesc: 'Renovación celular mientras descansas',
    features: JSON.stringify(['Retinol 1% encapsulado', 'Liberación gradual toda la noche', 'Sin irritación', 'Ácido hialurónico añadido', 'Resultados en 8 semanas']),
    benefits: JSON.stringify(['Reduce arrugas profundas', 'Unifica tono de piel', 'Minimiza poros', 'Piel más firme', 'Fórmula dermatológica']),
    price: 49.99,
    originalPrice: 79.99,
    commission: 42,
    rating: 4.7,
    reviewCount: 3180,
    affiliateUrl: 'https://shareasale.com/m-12347',
    imageUrl: 'https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd?w=400',
    brand: 'DermaAge',
    categorySlug: 'belleza-cuidado-piel',
    featured: false,
    bestSeller: true
  },
  {
    name: 'Mascarilla Facial LED 7 Colores',
    slug: 'mascarilla-facial-led-7-colores',
    description: 'Terapia LED profesional en casa. 7 modos de luz para tratar acné, arrugas, manchas y estimular colágeno. Usada por celebrities y dermatólogos.',
    shortDesc: 'Spa profesional en tu hogar',
    features: JSON.stringify(['7 colores de luz LED', '150 luces LED médicas', 'Temporizador automático', 'Cargador USB incluido', 'Gafas protectoras incluidas']),
    benefits: JSON.stringify(['Tratamiento profesional', 'Resultados desde semana 2', 'Sin productos químicos', 'Ahorra en tratamientos', 'Fácil de usar 10 min/día']),
    price: 129.99,
    originalPrice: 199.99,
    commission: 35,
    rating: 4.6,
    reviewCount: 1890,
    affiliateUrl: 'https://shareasale.com/m-12348',
    imageUrl: 'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?w=400',
    brand: 'LumiSkin',
    categorySlug: 'belleza-cuidado-piel',
    featured: true,
    bestSeller: false
  },

  // ===== SALUD Y BIENESTAR =====
  {
    name: 'Colágeno Hidrolizado Premium',
    slug: 'colageno-hidrolizado-premium',
    description: 'Colágeno tipo I y III de origen bovino certificado. 10,000mg por porción con vitamina C y biotina. Mejora piel, cabello, uñas y articulaciones.',
    shortDesc: 'Belleza desde adentro',
    features: JSON.stringify(['10,000mg por serving', 'Colágeno tipo I y III', 'Con vitamina C y biotina', 'Sin sabor, se mezcla fácil', '30 días de tratamiento']),
    benefits: JSON.stringify(['Piel más elástica', 'Cabello más fuerte', 'Uñas menos quebradizas', 'Articulaciones saludables', 'Absorción rápida']),
    price: 39.99,
    originalPrice: 59.99,
    commission: 45,
    rating: 4.8,
    reviewCount: 8920,
    affiliateUrl: 'https://shareasale.com/m-12349',
    imageUrl: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400',
    brand: 'VitalBeauty',
    categorySlug: 'salud-bienestar',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Gomitas Multivitamínicas Premium',
    slug: 'gomitas-multivitaminicas',
    description: 'Deliciosas gomitas con 13 vitaminas esenciales y minerales. Formato ideal para quienes no tragan pastillas. Sabor natural de frutas.',
    shortDesc: 'Vitaminas deliciosas para toda la familia',
    features: JSON.stringify(['13 vitaminas + minerales', 'Sabor frutas naturales', 'Sin azúcar añadida', 'Vegano y sin gluten', '60 gomitas por frasco']),
    benefits: JSON.stringify(['Energía todo el día', 'Sistema inmune fuerte', 'Piel radiante', 'Fácil de tomar', 'Ideal para toda la familia']),
    price: 24.99,
    originalPrice: 34.99,
    commission: 48,
    rating: 4.9,
    reviewCount: 12450,
    affiliateUrl: 'https://shareasale.com/m-12350',
    imageUrl: 'https://images.unsplash.com/photo-1550572017-edd951b55104?w=400',
    brand: 'NutriGummies',
    categorySlug: 'salud-bienestar',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Omega 3 + Vitamina D3',
    slug: 'omega-3-vitamina-d3',
    description: 'Aceite de pescado salvaje de Alaska con 2000mg EPA/DHA más 2000 UI de vitamina D3. Certificado libre de metales pesados.',
    shortDesc: 'Salud cardiovascular y cerebral',
    features: JSON.stringify(['2000mg EPA/DHA', '2000 UI Vitamina D3', 'Pescado salvaje de Alaska', 'Sin sabor a pescado', 'Certificado IFOS 5 estrellas']),
    benefits: JSON.stringify(['Corazón saludable', 'Mejor memoria y concentración', 'Ánimo estable', 'Huesos fuertes', 'Anti-inflamatorio natural']),
    price: 32.99,
    originalPrice: 44.99,
    commission: 42,
    rating: 4.7,
    reviewCount: 5670,
    affiliateUrl: 'https://shareasale.com/m-12351',
    imageUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400',
    brand: 'OmegaPure',
    categorySlug: 'salud-bienestar',
    featured: false,
    bestSeller: true
  },
  {
    name: 'Probióticos 50 Billones UFC',
    slug: 'probioticos-50-billones',
    description: 'Fórmula avanzada con 50 billones de organismos vivos y 16 cepas probióticas. Mejora digestión, inmunidad y bienestar intestinal.',
    shortDesc: 'Flora intestinal balanceada',
    features: JSON.stringify(['50 billones UFC', '16 cepas probióticas', 'Prebióticos incluidos', 'Liberación retardada', 'Refrigeración no requerida']),
    benefits: JSON.stringify(['Digestión óptima', 'Menos hinchazón', 'Sistema inmune fuerte', 'Más energía', 'Bienestar intestinal total']),
    price: 36.99,
    originalPrice: 49.99,
    commission: 44,
    rating: 4.8,
    reviewCount: 7230,
    affiliateUrl: 'https://shareasale.com/m-12352',
    imageUrl: 'https://images.unsplash.com/photo-1550572017-4e7d64e3f7ea?w=400',
    brand: 'GutHealth',
    categorySlug: 'salud-bienestar',
    featured: false,
    bestSeller: true
  },

  // ===== FITNESS Y DEPORTES =====
  {
    name: 'Banda de Resistencia Set Pro',
    slug: 'bandas-resistencia-set-pro',
    description: 'Set de 5 bandas de resistencia con diferentes niveles. Incluye manijas, ancla para puerta, bolsa y guía de ejercicios. Entrena donde quieras.',
    shortDesc: 'Tu gimnasio portátil',
    features: JSON.stringify(['5 niveles de resistencia', 'Hasta 150 lbs combinadas', 'Manijas acolchonadas', 'Ancla para puerta', 'Bolsa de transporte']),
    benefits: JSON.stringify(['Entrena en casa o viaje', 'Ejercicios ilimitados', 'Ideal principiantes y avanzados', 'Económico vs gimnasio', 'Resultados rápidos']),
    price: 34.99,
    originalPrice: 59.99,
    commission: 50,
    rating: 4.8,
    reviewCount: 15670,
    affiliateUrl: 'https://shareasale.com/m-12353',
    imageUrl: 'https://images.unsplash.com/photo-1598289431512-b97b0917affc?w=400',
    brand: 'FitBands',
    categorySlug: 'fitness-deportes',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Proteína Whey Isolada 2kg',
    slug: 'proteina-whey-isolada',
    description: 'Proteína whey aislada de máxima pureza. 27g de proteína por serving, 1g carbo, 0g azúcar. Sabor chocolate intenso. Ideal para musculación.',
    shortDesc: 'Máxima proteína, mínimo carbohidratos',
    features: JSON.stringify(['27g proteína por serving', '1g carbohidratos', '0g azúcar', 'BCAAs naturales', 'Sin lactosa']),
    benefits: JSON.stringify(['Músculo magro', 'Recuperación rápida', 'Sabor delicioso', 'Se mezcla sin grumos', 'Resultados comprobados']),
    price: 54.99,
    originalPrice: 79.99,
    commission: 40,
    rating: 4.7,
    reviewCount: 8940,
    affiliateUrl: 'https://shareasale.com/m-12354',
    imageUrl: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=400',
    brand: 'PowerFuel',
    categorySlug: 'fitness-deportes',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Rodillo de Espuma Premium',
    slug: 'rodillo-espuma-premium',
    description: 'Rodillo de espuma de alta densidad para masaje miofascial. Libera tensión muscular, mejora flexibilidad y acelera recuperación.',
    shortDesc: 'Recuperación muscular profesional',
    features: JSON.stringify(['Alta densidad EVA', '3 niveles de intensidad', 'Antideslizante', 'Ligero y durable', 'Incluye guía de ejercicios']),
    benefits: JSON.stringify(['Libera tensión muscular', 'Mejora flexibilidad', 'Acelera recuperación', 'Previene lesiones', 'Ideal post-entreno']),
    price: 29.99,
    originalPrice: 44.99,
    commission: 45,
    rating: 4.6,
    reviewCount: 6780,
    affiliateUrl: 'https://shareasale.com/m-12355',
    imageUrl: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=400',
    brand: 'RecoverPro',
    categorySlug: 'fitness-deportes',
    featured: false,
    bestSeller: false
  },

  // ===== CUIDADO PERSONAL =====
  {
    name: 'Cepillo de Dientes Eléctrico Sonic',
    slug: 'cepillo-dientes-electrico-sonic',
    description: 'Cepillo sónico con 40,000 vibraciones por minuto. 5 modos de limpieza, temporizador inteligente y 30 días de batería.',
    shortDesc: 'Limpieza dental profesional',
    features: JSON.stringify(['40,000 vibraciones/min', '5 modos de limpieza', 'Temporizador 2 minutos', '30 días de batería', '4 cabezales incluidos']),
    benefits: JSON.stringify(['Dientes más blancos', 'Encías más sanas', 'Menos placa', 'Dentista aprobado', 'Ahorra en limpiezas']),
    price: 49.99,
    originalPrice: 89.99,
    commission: 38,
    rating: 4.8,
    reviewCount: 9450,
    affiliateUrl: 'https://shareasale.com/m-12356',
    imageUrl: 'https://images.unsplash.com/photo-1559467010-c8c3f8b5ad6a?w=400',
    brand: 'DentFresh',
    categorySlug: 'cuidado-personal',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Depiladora Láser IPL Profesional',
    slug: 'depiladora-laser-ipl',
    description: 'Depilación láser IPL permanente en casa. 500,000 pulsos, 5 niveles de intensidad, resultados visibles en 4 semanas.',
    shortDesc: 'Depilación permanente sin dolor',
    features: JSON.stringify(['500,000 pulsos', '5 niveles intensidad', 'Tecnología IPL segura', 'Cabezal para cuerpo y rostro', 'Resultados permanentes']),
    benefits: JSON.stringify(['Sin más depilación', 'Ahorra miles en sesiones', 'Sin dolor', 'Piel suave siempre', 'Resultados garantizados']),
    price: 149.99,
    originalPrice: 249.99,
    commission: 35,
    rating: 4.7,
    reviewCount: 4230,
    affiliateUrl: 'https://shareasale.com/m-12357',
    imageUrl: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400',
    brand: 'SmoothSkin',
    categorySlug: 'cuidado-personal',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Secador de Pelo Profesional',
    slug: 'secador-pelo-profesional',
    description: 'Secador iónico profesional con motor AC potente. 3 temperaturas, 2 velocidades, boquilla concentradora y difusor incluidos.',
    shortDesc: 'Salón en casa',
    features: JSON.stringify(['Motor AC profesional', 'Tecnología iónica', '3 temperaturas', '2 velocidades', 'Boquilla y difusor incluidos']),
    benefits: JSON.stringify(['Secado ultra rápido', 'Sin frizz', 'Pelo brillante', 'Durabilidad profesional', 'Estilos ilimitados']),
    price: 69.99,
    originalPrice: 119.99,
    commission: 42,
    rating: 4.6,
    reviewCount: 5670,
    affiliateUrl: 'https://shareasale.com/m-12358',
    imageUrl: 'https://images.unsplash.com/photo-1522338242042-2d1c8e7b7e27?w=400',
    brand: 'ProStyle',
    categorySlug: 'cuidado-personal',
    featured: false,
    bestSeller: false
  },

  // ===== AROMATERAPIA Y SPA =====
  {
    name: 'Difusor de Aceites Esenciales',
    slug: 'difusor-aceites-esenciales',
    description: 'Difusor ultrasónico silencioso de 500ml con luces LED y 4 modos de temporizador. Ideal para aromaterapia, spa en casa y mejorar el sueño.',
    shortDesc: 'Bienestar aromático en tu hogar',
    features: JSON.stringify(['Capacidad 500ml', '4 temporizadores', '7 luces LED', 'Apagado automático', 'Ultra silencioso']),
    benefits: JSON.stringify(['Reduce estrés', 'Mejora el sueño', 'Purifica el ambiente', 'Hogar aromático', 'Ideal spa en casa']),
    price: 39.99,
    originalPrice: 59.99,
    commission: 48,
    rating: 4.8,
    reviewCount: 7890,
    affiliateUrl: 'https://shareasale.com/m-12359',
    imageUrl: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400',
    brand: 'ZenAroma',
    categorySlug: 'aromaterapia-spa',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Set 12 Aceites Esenciales Puros',
    slug: 'set-12-aceites-esenciales',
    description: 'Colección de 12 aceites esenciales 100% puros: lavanda, eucalipto, menta, tea tree, naranja, limón y más. Terapéuticos y sin aditivos.',
    shortDesc: 'Colección completa de aromaterapia',
    features: JSON.stringify(['12 aceites esenciales', '100% puros y naturales', 'Sin aditivos químicos', 'Botellas de 10ml', 'Guía de usos incluida']),
    benefits: JSON.stringify(['Relajación profunda', 'Respiración clara', 'Energía natural', 'Múltiples usos', 'Kit completo']),
    price: 44.99,
    originalPrice: 69.99,
    commission: 45,
    rating: 4.7,
    reviewCount: 5430,
    affiliateUrl: 'https://shareasale.com/m-12360',
    imageUrl: 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400',
    brand: 'PureNature',
    categorySlug: 'aromaterapia-spa',
    featured: true,
    bestSeller: true
  },
  {
    name: 'Piedras Calientes Spa Kit',
    slug: 'piedras-calientes-spa-kit',
    description: 'Kit completo de masaje con piedras volcánicas calientes. Incluye 16 piedras basálticas, calentador, aceites y guía de masaje.',
    shortDesc: 'Experiencia spa profesional',
    features: JSON.stringify(['16 piedras basálticas', 'Calentador digital', '2 aceites de masaje', 'Guía de técnicas', 'Bolsa de almacenamiento']),
    benefits: JSON.stringify(['Relajación total', 'Alivia dolores musculares', 'Spa en casa', 'Regalo perfecto', 'Calidad profesional']),
    price: 79.99,
    originalPrice: 129.99,
    commission: 40,
    rating: 4.5,
    reviewCount: 2340,
    affiliateUrl: 'https://shareasale.com/m-12361',
    imageUrl: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?w=400',
    brand: 'SpaHome',
    categorySlug: 'aromaterapia-spa',
    featured: false,
    bestSeller: false
  }
]

async function main() {
  console.log('🌱 Iniciando seed de productos de e-commerce afiliado...')

  // Crear categorías
  for (const category of categories) {
    await prisma.category.upsert({
      where: { slug: category.slug },
      update: category,
      create: category
    })
    console.log(`✅ Categoría creada: ${category.name}`)
  }

  // Crear productos
  for (const product of products) {
    const category = await prisma.category.findUnique({
      where: { slug: product.categorySlug }
    })
    
    if (category) {
      const { categorySlug, ...productData } = product
      await prisma.product.create({
        data: {
          ...productData,
          categoryId: category.id
        }
      })
      console.log(`✅ Producto creado: ${product.name} (${product.commission}% comisión)`)
    }
  }

  console.log('🎉 Seed completado!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
