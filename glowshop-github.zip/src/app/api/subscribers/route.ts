import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, name, source } = body

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 })
    }

    // Check if subscriber already exists
    const existing = await db.subscriber.findUnique({
      where: { email }
    })

    if (existing) {
      if (existing.active) {
        return NextResponse.json({ message: 'Ya estás suscrito!' })
      }
      // Reactivate
      await db.subscriber.update({
        where: { email },
        data: { active: true, name, source }
      })
      return NextResponse.json({ message: 'Suscripción reactivada!' })
    }

    // Create new subscriber
    await db.subscriber.create({
      data: { email, name, source }
    })

    return NextResponse.json({ message: 'Suscripción exitosa!' })
  } catch (error) {
    console.error('Error creating subscriber:', error)
    return NextResponse.json({ error: 'Error creating subscriber' }, { status: 500 })
  }
}
