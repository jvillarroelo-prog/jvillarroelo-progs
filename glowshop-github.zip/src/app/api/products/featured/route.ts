import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const products = await db.product.findMany({
      where: { 
        active: true,
        featured: true 
      },
      include: { category: true },
      orderBy: { rating: 'desc' }
    })
    return NextResponse.json(products)
  } catch (error) {
    console.error('Error fetching featured products:', error)
    return NextResponse.json({ error: 'Error fetching featured products' }, { status: 500 })
  }
}
