import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, name, interest, message } = body

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 })
    }

    await db.lead.create({
      data: { email, name, interest, message }
    })

    return NextResponse.json({ message: 'Mensaje enviado!' })
  } catch (error) {
    console.error('Error creating lead:', error)
    return NextResponse.json({ error: 'Error creating lead' }, { status: 500 })
  }
}
